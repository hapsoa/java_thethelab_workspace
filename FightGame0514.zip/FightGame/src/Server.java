import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

public class Server {

    static volatile Map map = new Map();
    private static volatile ConcurrentHashMap<SocketConnector, String> data = new ConcurrentHashMap<>();
    private static ServerSocketConnector serverSocketConnector = null;
    private static volatile List<Client> clients = new CopyOnWriteArrayList<>();


    private static void broadcast(String s, SocketConnector socketConnector) {

        JsonParser parser = new JsonParser();

        JsonObject object = (JsonObject) parser.parse(s);
        JsonObject body = object.getAsJsonObject("body");

        String type = object.get("type").toString().replaceAll("\"", "");

        switch (type) {
            case "Join":
                String name = body.get("user").toString().replaceAll("\"", "");
                clients.add(new Client(name));
                data.put(socketConnector, name);
                break;
            case "Kill":
                break;
            case "Move":
                for(Client client : clients){
                    if(client.user.equals(data.get(socketConnector))){
                        client.direction = body.get("direction").toString().replaceAll("\"", "");
                        client.state = type;
                        break;
                    }
                }
                break;
            case "Stop":
                for(Client client : clients){
                    if(client.user.equals(data.get(socketConnector))) {
                        client.state = type;
                        break;
                    }
                }
                break;
            case "Hit":
                //유저의 이름으로 클라이언트를 찾고 방향으로 위치 인덱스를 찾아서 거기 사람놈들이 있으면 맞는다
                break;
            case "ItemCreate":
                break;
            case "ItemConsume":
                break;

        }
        serverSocketConnector.send(s);
    }

    public static void main(String[] args) {
        serverSocketConnector = new ServerSocketConnector(5000);
        serverSocketConnector.setReceiver(Server::broadcast);
        Socket socket;

        new Thread(() -> {
            while(true){
                JsonArray userArray = new JsonArray();
                for(Client client : clients){
                    client.update();// 600, 300  -> 오른쪽 방향               // 60번을 오른쪽으롬 감  --> 720, 300

                    userArray.add(client.getClientAsJsonObject());
                }
                JsonObject dataObject = new JsonObject();
                dataObject.addProperty("type", "Update");
                dataObject.add("users", userArray);
                serverSocketConnector.send(new Gson().toJson(dataObject));
                try {
                    TimeUnit.MILLISECONDS.sleep(30);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        while (true) {
            try {
                socket = serverSocketConnector.serverSocket.accept();
                SocketConnector socketConnector = new SocketConnector(socket);
                serverSocketConnector.add(socketConnector);
                serverSocketConnector.connect(socketConnector);
                serverSocketConnector.send(map.getMapObjectAsString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}