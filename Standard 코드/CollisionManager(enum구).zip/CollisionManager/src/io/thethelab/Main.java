package io.thethelab;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Window.main("io.thethelab.Window");
    }
}
