public class CollisionDetector {

    public static boolean checkSquareDot(){
        return true;
    }


}
