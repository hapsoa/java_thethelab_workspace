package io.thethelab;

public interface Move {

}
